import React, { useMemo, useState, useEffect } from "react";
import { BadgeCheck, Download, Mail, Phone, MapPin, Github, Linkedin, ExternalLink, Search, Filter, X, ArrowUpRight, Moon, Sun, ChevronUp, Star, Sparkles } from "lucide-react";

const DATA = {
  name: "GRETA ANJALIN D",
  title: "Software Engineer",
  summary: "Software Engineer with 2.7+ years of experience in full‑stack development of web and mobile apps. Proven expertise in responsive design, user interaction optimization, and debugging scalable front‑end and back‑end systems. Skilled in RESTful APIs, API Gateway, CI/CD, authentication (JWT/OAuth), and cloud deployments. Strong in troubleshooting, collaboration, and maintaining visual design standards.",
  location: "Chennai, India",
  email: "gretaregina31@gmail.com",
  phone: "+91 8248260844",
  links: {
    github: "https://github.com/greta-anjalin",
    linkedin: "#",
    resume: "/GRETA-ANJALIN-Resume.pdf",
    portfolio: "#",
  },
  experience: [
    {
      company: "Invent Softlabs (India) Pvt. Ltd.",
      role: "Software Engineer",
      timeframe: "Feb 2023 – Present",
      bullets: [
        "Engineered cross‑platform mobile and web apps using React, Flutter, Next.js, and Angular.",
        "Implemented RESTful APIs and scalable server‑side logic using Node.js, NestJS, Java, and C#.",
        "Optimized web pages for performance, improving load time by 40%.",
        "Designed secure authentication workflows with JWT and role‑based access.",
        "Debugged and tested microservices with unit testing, TDD, and CI/CD pipelines.",
        "Maintained visual and responsive design standards across platforms.",
        "Led technical writing, documentation, and knowledge‑sharing sessions.",
      ],
    },
  ],
  skills: {
    Frontend: ["React", "Angular", "Flutter", "Next.js", "Bootstrap", "HTML5", "CSS", "JavaScript", "TypeScript", "Tailwind CSS", "Sass", "Redux", "Recoil"],
    Backend: ["Node.js", "NestJS", "C#", "ASP.NET", "Java Spring Boot", "FastAPI"],
    Mobile: ["Flutter (iOS & Android)", "React Native", "Capacitor", "Responsive & Mobile‑First"],
    Architecture: ["Microservices", "MVC", "Server‑Side & Client‑Side Programming", "Middleware"],
    "Web Design": ["UI/UX Design", "Visual Design", "Web Pages & Interactions"],
    Database: ["MS SQL", "MySQL", "PostgreSQL", "ObjectBox"],
    "Tools & DevOps": ["Git", "GitHub", "RabbitMQ", "Figma"],
    Testing: ["Unit Testing", "TDD", "Manual Testing", "Functional Testing", "Debugging", "Integration Testing"],
    "Auth & Security": ["JWT", "OAuth2", "Secure Login"],
    "Cloud & Deployment": ["Azure Fundamentals", "Deployment Pipelines"],
    "Soft Skills": ["Team Collaboration", "Problem Solving", "Communication", "Documentation", "Attention to Detail", "Adaptability"],
  },
  projects: [
    {
      title: "Dofy Ecommerce",
      stack: ["Next.js", "C#", "ASP.NET MVC", "Blazor", "SQL Server"],
      bullets: [
        "Developed complete frontend (Next.js) and backend (C#) for a full‑fledged e‑commerce platform.",
        "Built core modules: Add to Cart, Checkout, Invoice (HTML‑to‑PDF), dynamic product variants.",
        "Implemented delivery date‑time scheduling, order/cart logic, and admin panel using MVC.",
        "Optimized checkout module, reducing page load by 40%.",
      ],
    },
    {
      title: "TickDot – Task Management App",
      stack: ["Flutter", "NestJS", "Firebase", "ObjectBox", "PostgreSQL"],
      bullets: [
        "Trello‑style task app with real‑time sync using ObjectBox.",
        "Firebase push notifications and OTP auth.",
        "Drag‑and‑drop task UI and hierarchical updates.",
        "Secure, scalable multi‑role appointment system on NestJS + PostgreSQL.",
      ],
    },
    {
      title: "Dofy (Next.js Migration)",
      stack: ["React", "Next.js", "C#", "SQL Server"],
      bullets: [
        "Migrated from React to Next.js boosting performance and SEO.",
        "Built rider, vendor, audit log, and feedback modules from scratch.",
        "Implemented multi‑database and language switching logic.",
        "Resolved complex microservice bugs; improved stability.",
      ],
    },
    {
      title: "Plooma",
      stack: ["Angular", "C#", "SQL Server", "Stripe"],
      bullets: [
        "US‑based therapy platform: patient/provider management.",
        "Payment and appointment calendar features.",
        "Multi‑role web UI with secure, scalable backend integration.",
      ],
    },
    {
      title: "CRM",
      stack: ["React", "C#", "SQL Server"],
      bullets: [
        "Led development of CRM with scheduling and tracking.",
        "Calendar module with reminders and alerts.",
        "Collaborated cross‑functionally to align with business goals.",
      ],
    },
    {
      title: "TNIdol (Govt Project)",
      stack: ["Angular", "Node.js", "PostgreSQL"],
      bullets: [
        "Web platform for Tamil Nadu Police Wing to rescue and count idols.",
        "Led frontend: visually appealing, user‑friendly UI.",
        "Seamless integration with backend for efficient data processing.",
      ],
    },
  ],
  education: [
    {
      degree: "B.E. Electronics and Communication Engineering",
      school: "Sree Sowdambika College of Engineering",
      years: "2019 – 2023",
    },
  ],
  certifications: [
    "Microsoft Certified: Azure AI Fundamentals",
    "Microsoft Certified: AZ‑900 (Azure Fundamentals)",
  ],
};

// Animated star field component
const StarField = () => {
  const [stars, setStars] = useState([]);

  useEffect(() => {
    const newStars = Array.from({ length: 200 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1,
      opacity: Math.random() * 0.8 + 0.2,
      twinkleDelay: Math.random() * 3,
    }));
    setStars(newStars);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full bg-white animate-pulse"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            animationDelay: `${star.twinkleDelay}s`,
          }}
        />
      ))}
    </div>
  );
};

// Floating particles component
const FloatingParticles = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 50 }, (_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-blue-400 rounded-full opacity-30 animate-float"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 5}s`,
            animationDuration: `${3 + Math.random() * 4}s`,
          }}
        />
      ))}
    </div>
  );
};

// Cosmic card component
const CosmicCard = ({ children, className = "", hover = true, ...props }) => (
  <div
    className={`relative overflow-hidden rounded-2xl bg-gradient-to-br from-gray-900/80 via-slate-800/60 to-gray-900/80 backdrop-blur-xl border border-gray-600/30 shadow-2xl ${hover ? 'hover:shadow-cyan-500/20 hover:border-cyan-500/40 hover:-translate-y-2 transition-all duration-500' : ''} ${className}`}
    {...props}
  >
    <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-purple-600/5 to-cyan-600/5" />
    <div className="relative z-10">
      {children}
    </div>
  </div>
);

// Glowing button component
const GlowButton = ({ children, icon: Icon, variant = "primary", className = "", ...props }) => {
  const baseClasses = "relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-2xl";

  const variants = {
    primary: "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/50 hover:shadow-cyan-500/70",
    secondary: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-500/50 hover:shadow-purple-500/70",
    outline: "border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-900 shadow-cyan-400/30 hover:shadow-cyan-400/50",
  };

  return (
    <button className={`${baseClasses} ${variants[variant]} ${className}`} {...props}>
      <span className="relative z-10 flex items-center gap-2">
        {Icon && <Icon className="w-5 h-5" />}
        {children}
      </span>
      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300" />
    </button>
  );
};

// Skill pill with glow effect
const SkillPill = ({ children }) => (
  <span className="inline-flex items-center px-4 py-2 text-sm font-semibold text-cyan-300 bg-gradient-to-r from-cyan-900/40 to-blue-900/40 rounded-full border border-cyan-500/30 shadow-md hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105 hover:border-cyan-400/50">
    {children}
  </span>
);

// Section component with cosmic styling
const Section = ({ id, title, children, description }) => (
  <section id={id} className="relative py-24 px-6 max-w-7xl mx-auto">
    <div className="text-center mb-16">
      <h2 className="text-5xl md:text-6xl font-extrabold bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent mb-6 tracking-tight">
        {title}
      </h2>
      {description && (
        <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed font-medium">
          {description}
        </p>
      )}
      <div className="flex justify-center mt-8">
        <div className="w-32 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent rounded-full" />
      </div>
    </div>
    {children}
  </section>
);

export default function App() {
  const [query, setQuery] = useState("");
  const [activeTags, setActiveTags] = useState([]);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const allTags = useMemo(() => {
    const t = new Set();
    DATA.projects.forEach((p) => p.stack.forEach((s) => t.add(s)));
    return Array.from(t).sort();
  }, []);

  const filteredProjects = useMemo(() => {
    return DATA.projects.filter((p) => {
      const q = query.trim().toLowerCase();
      const matchesQuery = !q || p.title.toLowerCase().includes(q) || p.stack.join(" ").toLowerCase().includes(q);
      const matchesTags = activeTags.length === 0 || activeTags.every((t) => p.stack.includes(t));
      return matchesQuery && matchesTags;
    });
  }, [query, activeTags]);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-slate-900 text-white overflow-hidden">
      {/* Cosmic background elements */}
      <StarField />
      <FloatingParticles />

      {/* Cosmic gradient overlays */}
      <div className="fixed inset-0 bg-gradient-to-br from-blue-900/20 via-transparent to-purple-900/20 pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(147,51,234,0.15),transparent_50%)] pointer-events-none" />

      {/* Navigation */}
      <header className="fixed top-0 w-full z-50 backdrop-blur-xl bg-black/20 border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="#top" className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent hover:from-cyan-300 hover:to-blue-400 transition-all duration-300">
            {DATA.name}
          </a>

          <nav className="hidden md:flex items-center gap-8 text-lg font-semibold">
            {["about", "skills", "experience", "projects", "education", "contact"].map((section) => (
              <a
                key={section}
                href={`#${section}`}
                className="relative text-gray-300 hover:text-cyan-400 transition-colors duration-300 group"
              >
                {section.charAt(0).toUpperCase() + section.slice(1)}
                <span className="absolute -bottom-2 left-0 w-0 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <a href={DATA.links.resume} target="_blank" rel="noreferrer">
              <GlowButton className="text-sm px-6 py-3" icon={Download}>
                Resume
              </GlowButton>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10">
        <section id="top" className="min-h-screen flex items-center justify-center px-6">
          <div className="max-w-7xl mx-auto text-center">
            <div className="mb-8">
              {/* <Sparkles className="w-8 h-8 mt-20 text-cyan-400 mx-auto mb-8 animate-pulse" /> */}
            </div>

            {/* <h1 className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-extrabold mb-8 leading-none">
              <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
                {DATA.name}
              </span>
            </h1> */}

            <p className="text-2xl md:text-3xl lg:text-4xl text-cyan-300 font-bold mb-8 tracking-wide">
              {DATA.title}
            </p>

            <p className="text-xl md:text-2xl text-gray-300 max-w-5xl mx-auto leading-relaxed mb-12 font-medium">
              {DATA.summary}
            </p>

            {/* Contact Info */}
            <div className="flex flex-wrap justify-center items-center gap-8 mb-12 text-lg">
              <div className="flex items-center gap-3 text-gray-300">
                <MapPin className="w-6 h-6 text-cyan-400" />
                {DATA.location}
              </div>
              <a href={`mailto:${DATA.email}`} className="flex items-center gap-3 text-gray-300 hover:text-cyan-400 transition-colors">
                <Mail className="w-6 h-6 text-cyan-400" />
                {DATA.email}
              </a>
              <a href={`tel:${DATA.phone.replace(/\s/g, '')}`} className="flex items-center gap-3 text-gray-300 hover:text-cyan-400 transition-colors">
                <Phone className="w-6 h-6 text-cyan-400" />
                {DATA.phone}
              </a>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap justify-center gap-6">
              {DATA.links.github && (
                <a href={DATA.links.github} target="_blank" rel="noreferrer">
                  <GlowButton icon={Github}>
                    GitHub
                  </GlowButton>
                </a>
              )}
              {DATA.links.linkedin && (
                <a href={DATA.links.linkedin} target="_blank" rel="noreferrer">
                  <GlowButton variant="secondary" icon={Linkedin}>
                    LinkedIn
                  </GlowButton>
                </a>
              )}
              {/* {DATA.links.portfolio && (
                <a href={DATA.links.portfolio} target="_blank" rel="noreferrer">
                  <GlowButton variant="outline">
                    <ExternalLink className="w-5 h-5 mr-3" />
                    Portfolio
                  </GlowButton>
                </a>
              )} */}
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <Section id="skills" title="Skills" description="Technologies and expertise that power my development journey">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Object.entries(DATA.skills).map(([category, list], i) => (
              <CosmicCard key={category} className="p-8">
                <div className="flex items-center gap-3 mb-6">
                  <Star className="w-6 h-6 text-cyan-400" />
                  <h3 className="text-2xl font-bold text-white">{category}</h3>
                </div>
                <div className="flex flex-wrap gap-3">
                  {list.map((skill) => (
                    <SkillPill key={skill}>{skill}</SkillPill>
                  ))}
                </div>
              </CosmicCard>
            ))}
          </div>
        </Section>

        {/* Experience Section */}
        <Section id="experience" title="Experience">
          <div className="space-y-16">
            {DATA.experience.map((exp, i) => (
              <CosmicCard key={i} className="p-10">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-2">{exp.role}</h3>
                    <p className="text-xl text-cyan-300 font-semibold">{exp.company}</p>
                  </div>
                  <div className="text-lg text-gray-400 font-medium mt-4 lg:mt-0">
                    {exp.timeframe}
                  </div>
                </div>
                <ul className="space-y-4">
                  {exp.bullets.map((bullet, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-lg text-gray-300 leading-relaxed">
                      <BadgeCheck className="w-6 h-6 text-cyan-400 mt-0.5 flex-shrink-0" />
                      {bullet}
                    </li>
                  ))}
                </ul>
              </CosmicCard>
            ))}
          </div>
        </Section>

        {/* Projects Section */}
        <Section id="projects" title="Projects" description="Innovative solutions and applications I've built">
          {/* Search and Filter */}
          <div className="mb-12 space-y-6">
            <div className="flex flex-col md:flex-row gap-6 items-center justify-center">
              <div className="relative max-w-md w-full">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full pl-12 pr-6 py-4 bg-gray-900/60 border border-gray-600/40 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400/60 focus:shadow-lg focus:shadow-cyan-500/20 transition-all backdrop-blur-sm"
                />
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              {allTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setActiveTags(prev =>
                    prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
                  )}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${activeTags.includes(tag)
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30'
                    : 'bg-gray-800/60 text-gray-300 border border-gray-600/40 hover:border-cyan-400/40 hover:text-cyan-300'
                    }`}
                >
                  {tag}
                </button>
              ))}
              {activeTags.length > 0 && (
                <button
                  onClick={() => setActiveTags([])}
                  className="px-4 py-2 rounded-full text-sm font-semibold bg-red-600/20 text-red-400 border border-red-500/40 hover:bg-red-600/30 transition-all duration-300 flex items-center gap-2"
                >
                  <X className="w-4 h-4" />
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Project Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, i) => (
              <CosmicCard key={project.title} className="p-8 group cursor-pointer">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">{project.title}</h3>
                  <ArrowUpRight className="w-6 h-6 text-cyan-400 group-hover:rotate-45 transition-transform duration-300" />
                </div>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.stack.map((tech) => (
                    <span key={tech} className="px-3 py-1 text-xs font-semibold text-cyan-300 bg-cyan-900/30 rounded-full border border-cyan-500/20">
                      {tech}
                    </span>
                  ))}
                </div>

                <ul className="space-y-3">
                  {project.bullets.map((bullet, idx) => (
                    <li key={idx} className="text-sm text-gray-300 leading-relaxed flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full mt-2 flex-shrink-0" />
                      {bullet}
                    </li>
                  ))}
                </ul>
              </CosmicCard>
            ))}
          </div>
        </Section>

        {/* Education Section */}
        <Section id="education" title="Education">
          <div className="max-w-4xl mx-auto">
            {DATA.education.map((edu, i) => (
              <CosmicCard key={edu.degree} className="p-10 text-center">
                <h3 className="text-3xl font-bold text-white mb-4">{edu.degree}</h3>
                <p className="text-xl text-cyan-300 font-semibold mb-4">{edu.school}</p>
                <p className="text-lg text-gray-400">{edu.years}</p>
              </CosmicCard>
            ))}

            {/* Certifications */}
            <CosmicCard className="p-10 mt-8">
              <h3 className="text-3xl font-bold text-white text-center mb-8">Certifications</h3>
              <div className="space-y-4">
                {DATA.certifications.map((cert) => (
                  <div key={cert} className="flex items-center gap-4 text-lg text-gray-300">
                    <BadgeCheck className="w-6 h-6 text-cyan-400 flex-shrink-0" />
                    {cert}
                  </div>
                ))}
              </div>
            </CosmicCard>
          </div>
        </Section>

        {/* Contact Section */}
        <Section id="contact" title="Contact">
          <CosmicCard className="p-12 text-center max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-white mb-8">Let's Connect</h3>
            <p className="text-xl text-gray-300 mb-12 leading-relaxed">
              Ready to bring your ideas to life? Let's discuss how we can work together.
            </p>

            <div className="flex flex-wrap justify-center gap-6">
              <a href={`mailto:${DATA.email}`}>
                <GlowButton icon={Mail}>
                  Email Me
                </GlowButton>
              </a>
              <a href={`tel:${DATA.phone.replace(/\s/g, '')}`}>
                <GlowButton variant="secondary" icon={Phone}>
                  Call Me
                </GlowButton>
              </a>
              {DATA.links.github && (
                <a href={DATA.links.github} target="_blank" rel="noreferrer">
                  <GlowButton variant="outline" icon={Github}>
                    GitHub
                  </GlowButton>
                </a>
              )}
            </div>
          </CosmicCard>
        </Section>

        {/* Footer */}
        <footer className="py-16 text-center text-gray-400 border-t border-gray-800/50 max-w-7xl mx-auto px-6">
          <p className="text-lg">
            © {new Date().getFullYear()} {DATA.name}. Crafted with passion in the cosmic void.
          </p>
        </footer>
      </main>

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-full shadow-2xl hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-110 z-50 group"
          aria-label="Back to top"
        >
          <ChevronUp className="w-6 h-6 group-hover:-translate-y-1 transition-transform" />
        </button>
      )}

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </div>
  );
}